// library.h

#ifndef _LIBRARY_H
#define _LIBRARY_H

#include "holding.h"
#include "book.h"
#include "recording.h"

int main();
const int SIZE = 256;
Holding * libraryFunct();

#endif